import axios from 'axios';

const API_URL = '/api';

// Create axios instance
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Item services
export const itemService = {
  // Get all items
  getAllItems: async () => {
    const response = await apiClient.get('/items');
    return response.data;
  },

  // Get item by ID
  getItemById: async (id) => {
    const response = await apiClient.get(`/items/${id}`);
    return response.data;
  },

  // Create new item
  createItem: async (itemData) => {
    const response = await apiClient.post('/items', itemData);
    return response.data;
  },

  // Update an item
  updateItem: async (id, itemData) => {
    const response = await apiClient.put(`/items/${id}`, itemData);
    return response.data;
  },

  // Delete an item
  deleteItem: async (id) => {
    const response = await apiClient.delete(`/items/${id}`);
    return response.data;
  },

  // Archive an item
  archiveItem: async (id) => {
    const response = await apiClient.put(`/items/${id}/archive`);
    return response.data;
  },

  // Bulk update items
  bulkUpdateItems: async (itemIds, updates) => {
    const response = await apiClient.patch('/items/bulk', { itemIds, updates });
    return response.data;
  },
};

// Dashboard services
export const dashboardService = {
  // Get dashboard data
  getDashboardData: async () => {
    const response = await apiClient.get('/dashboard');
    return response.data;
  },
};

// Metadata services
export const metadataService = {
  // Get categories and suppliers
  getMetadata: async () => {
    const response = await apiClient.get('/metadata');
    return response.data;
  },
};

// Import/Export services
export const importExportService = {
  // Import items
  importItems: async (items) => {
    const response = await apiClient.post('/import', items);
    return response.data;
  },

  // Export is handled client-side by downloading the data
  // This is just a helper function to format the data
  exportItems: (items) => {
    return items;
  },
};

export default {
  itemService,
  dashboardService,
  metadataService,
  importExportService,
};
