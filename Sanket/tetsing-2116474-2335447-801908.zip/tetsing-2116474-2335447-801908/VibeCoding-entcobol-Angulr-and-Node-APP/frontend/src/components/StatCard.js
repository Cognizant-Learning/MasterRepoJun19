import React from 'react';
import { Card, CardContent, Typography, Box, CircularProgress } from '@mui/material';
import { styled } from '@mui/material/styles';

const StyledCard = styled(Card)(({ theme, bgcolor }) => ({
  minWidth: 200,
  height: '100%',
  backgroundColor: bgcolor || theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
}));

const StatCard = ({ title, value, icon, isLoading, bgcolor }) => {
  return (
    <StyledCard bgcolor={bgcolor}>
      <CardContent>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Box>
            <Typography variant="subtitle2" color="inherit" gutterBottom>
              {title}
            </Typography>
            {isLoading ? (
              <CircularProgress size={30} color="inherit" />
            ) : (
              <Typography variant="h4" component="div" fontWeight="bold">
                {value}
              </Typography>
            )}
          </Box>
          <Box>
            {icon}
          </Box>
        </Box>
      </CardContent>
    </StyledCard>
  );
};

export default StatCard;
