import React from 'react';
import { 
  DataGrid, 
  GridToolbar,
} from '@mui/x-data-grid';
import { 
  Box, 
  Typography, 
  CircularProgress,
  Paper,
} from '@mui/material';

const InventoryTable = ({
  rows,
  columns,
  loading,
  pageSize = 10,
  onRowClick,
  checkboxSelection = false,
  selectionModel,
  onSelectionModelChange
}) => {
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 400 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!rows || rows.length === 0) {
    return (
      <Paper elevation={2} sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6" color="text.secondary">
          No inventory items found
        </Typography>
      </Paper>
    );
  }
  return (
    <Box sx={{ height: 500, width: '100%' }}>      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={pageSize}
        rowsPerPageOptions={[5, 10, 20]}
        checkboxSelection={checkboxSelection}
        disableSelectionOnClick
        components={{
          Toolbar: GridToolbar,
        }}
        componentsProps={{
          toolbar: {
            showQuickFilter: true,
            quickFilterProps: { debounceMs: 500 },
          },
        }}
        onRowClick={onRowClick}
        selectionModel={selectionModel}
        onSelectionModelChange={onSelectionModelChange}
        loading={loading}
        sx={{
          '&.MuiDataGrid-root .MuiDataGrid-cell:focus': {
            outline: 'none',
          },
        }}
      />
    </Box>
  );
};

export default InventoryTable;
