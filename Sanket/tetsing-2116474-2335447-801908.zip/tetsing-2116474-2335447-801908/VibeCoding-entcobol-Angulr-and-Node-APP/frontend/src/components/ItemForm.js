import React from 'react';
import { 
  TextField, 
  Grid, 
  MenuItem, 
  Button, 
  Paper, 
  Typography, 
  Box,
  CircularProgress,
  Divider
} from '@mui/material';
import { useFormik } from 'formik';
import * as yup from 'yup';

// Validation schema
const validationSchema = yup.object({
  name: yup
    .string()
    .required('Name is required'),
  description: yup
    .string()
    .required('Description is required'),
  category: yup
    .string()
    .required('Category is required'),
  sku: yup
    .string()
    .required('SKU is required'),
  price: yup
    .number()
    .positive('Price must be positive')
    .required('Price is required'),
  quantity: yup
    .number()
    .integer('Quantity must be an integer')
    .min(0, 'Quantity cannot be negative')
    .required('Quantity is required'),
  supplier: yup
    .string()
    .required('Supplier is required'),
  minStockThreshold: yup
    .number()
    .integer('Threshold must be an integer')
    .min(0, 'Threshold cannot be negative')
    .required('Minimum stock threshold is required'),
});

const ItemForm = ({ 
  initialValues = {
    name: '',
    description: '',
    category: '',
    sku: '',
    price: '',
    quantity: '',
    supplier: '',
    imageUrl: '',
    minStockThreshold: '',
  }, 
  onSubmit, 
  categories = [], 
  suppliers = [],
  isLoading = false,
  isEditMode = false,
}) => {
  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      onSubmit(values);
    },
  });

  return (
    <Paper elevation={3} sx={{ p: 4 }}>
      <Box mb={3}>
        <Typography variant="h5" gutterBottom>
          {isEditMode ? 'Edit Inventory Item' : 'Add New Inventory Item'}
        </Typography>
        <Divider />
      </Box>

      <form onSubmit={formik.handleSubmit}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              id="name"
              name="name"
              label="Item Name"
              value={formik.values.name}
              onChange={formik.handleChange}
              error={formik.touched.name && Boolean(formik.errors.name)}
              helperText={formik.touched.name && formik.errors.name}
              variant="outlined"
              disabled={isLoading}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              id="sku"
              name="sku"
              label="SKU"
              value={formik.values.sku}
              onChange={formik.handleChange}
              error={formik.touched.sku && Boolean(formik.errors.sku)}
              helperText={formik.touched.sku && formik.errors.sku}
              variant="outlined"
              disabled={isLoading}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              fullWidth
              id="description"
              name="description"
              label="Description"
              multiline
              rows={3}
              value={formik.values.description}
              onChange={formik.handleChange}
              error={formik.touched.description && Boolean(formik.errors.description)}
              helperText={formik.touched.description && formik.errors.description}
              variant="outlined"
              disabled={isLoading}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              id="category"
              name="category"
              select
              label="Category"
              value={formik.values.category}
              onChange={formik.handleChange}
              error={formik.touched.category && Boolean(formik.errors.category)}
              helperText={formik.touched.category && formik.errors.category}
              variant="outlined"
              disabled={isLoading}
            >
              {categories.map((category) => (
                <MenuItem key={category} value={category}>
                  {category}
                </MenuItem>
              ))}
            </TextField>
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              id="supplier"
              name="supplier"
              select
              label="Supplier"
              value={formik.values.supplier}
              onChange={formik.handleChange}
              error={formik.touched.supplier && Boolean(formik.errors.supplier)}
              helperText={formik.touched.supplier && formik.errors.supplier}
              variant="outlined"
              disabled={isLoading}
            >
              {suppliers.map((supplier) => (
                <MenuItem key={supplier} value={supplier}>
                  {supplier}
                </MenuItem>
              ))}
            </TextField>
          </Grid>

          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              id="price"
              name="price"
              type="number"
              label="Price"
              value={formik.values.price}
              onChange={formik.handleChange}
              error={formik.touched.price && Boolean(formik.errors.price)}
              helperText={formik.touched.price && formik.errors.price}
              variant="outlined"
              InputProps={{ inputProps: { min: 0, step: 0.01 } }}
              disabled={isLoading}
            />
          </Grid>

          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              id="quantity"
              name="quantity"
              type="number"
              label="Quantity"
              value={formik.values.quantity}
              onChange={formik.handleChange}
              error={formik.touched.quantity && Boolean(formik.errors.quantity)}
              helperText={formik.touched.quantity && formik.errors.quantity}
              variant="outlined"
              InputProps={{ inputProps: { min: 0, step: 1 } }}
              disabled={isLoading}
            />
          </Grid>

          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              id="minStockThreshold"
              name="minStockThreshold"
              type="number"
              label="Minimum Stock Threshold"
              value={formik.values.minStockThreshold}
              onChange={formik.handleChange}
              error={formik.touched.minStockThreshold && Boolean(formik.errors.minStockThreshold)}
              helperText={formik.touched.minStockThreshold && formik.errors.minStockThreshold}
              variant="outlined"
              InputProps={{ inputProps: { min: 0, step: 1 } }}
              disabled={isLoading}
            />
          </Grid>

          <Grid item xs={12}>
            <TextField
              fullWidth
              id="imageUrl"
              name="imageUrl"
              label="Image URL (optional)"
              value={formik.values.imageUrl}
              onChange={formik.handleChange}
              variant="outlined"
              disabled={isLoading}
            />
          </Grid>

          <Grid item xs={12}>
            <Box display="flex" justifyContent="flex-end" gap={2} mt={2}>
              <Button
                variant="contained"
                color="primary"
                type="submit"
                disabled={isLoading}
              >
                {isLoading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : isEditMode ? 'Update Item' : 'Add Item'}
              </Button>
            </Box>
          </Grid>
        </Grid>
      </form>
    </Paper>
  );
};

export default ItemForm;
