import React, { createContext, useState, useContext, useEffect } from 'react';
import { itemService, dashboardService, metadataService } from '../services/api';

// Create Context
const InventoryContext = createContext();

export const useInventory = () => useContext(InventoryContext);

export const InventoryProvider = ({ children }) => {
  const [items, setItems] = useState([]);
  const [dashboardData, setDashboardData] = useState({
    summary: { totalItems: 0, lowStockItems: 0, outOfStockItems: 0 },
    recentActivity: []
  });
  const [metadata, setMetadata] = useState({ categories: [], suppliers: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load initial data
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        setLoading(true);
        
        // Fetch items
        const itemsData = await itemService.getAllItems();
        setItems(itemsData);
        
        // Fetch dashboard data
        const dashboard = await dashboardService.getDashboardData();
        setDashboardData(dashboard);
        
        // Fetch metadata
        const meta = await metadataService.getMetadata();
        setMetadata(meta);
        
        setLoading(false);
      } catch (error) {
        console.error('Error loading initial data:', error);
        setError('Failed to load data. Please try again.');
        setLoading(false);
      }
    };

    fetchInitialData();
  }, []);

  // Create an item
  const createItem = async (itemData) => {
    try {
      const newItem = await itemService.createItem(itemData);
      setItems(prevItems => [...prevItems, newItem]);
      // Refresh dashboard data
      const dashboard = await dashboardService.getDashboardData();
      setDashboardData(dashboard);
      return newItem;
    } catch (error) {
      console.error('Error creating item:', error);
      throw error;
    }
  };

  // Update an item
  const updateItem = async (id, itemData) => {
    try {
      const updatedItem = await itemService.updateItem(id, itemData);
      setItems(prevItems => 
        prevItems.map(item => item.id === id ? updatedItem : item)
      );
      // Refresh dashboard data
      const dashboard = await dashboardService.getDashboardData();
      setDashboardData(dashboard);
      return updatedItem;
    } catch (error) {
      console.error('Error updating item:', error);
      throw error;
    }
  };

  // Delete an item
  const deleteItem = async (id) => {
    try {
      await itemService.deleteItem(id);
      setItems(prevItems => prevItems.filter(item => item.id !== id));
      // Refresh dashboard data
      const dashboard = await dashboardService.getDashboardData();
      setDashboardData(dashboard);
      return true;
    } catch (error) {
      console.error('Error deleting item:', error);
      throw error;
    }
  };

  // Archive an item
  const archiveItem = async (id) => {
    try {
      const archivedItem = await itemService.archiveItem(id);
      setItems(prevItems => 
        prevItems.map(item => item.id === id ? archivedItem : item)
      );
      // Refresh dashboard data
      const dashboard = await dashboardService.getDashboardData();
      setDashboardData(dashboard);
      return archivedItem;
    } catch (error) {
      console.error('Error archiving item:', error);
      throw error;
    }
  };

  // Bulk update items
  const bulkUpdateItems = async (itemIds, updates) => {
    try {
      const result = await itemService.bulkUpdateItems(itemIds, updates);
      // Refresh all items
      const updatedItems = await itemService.getAllItems();
      setItems(updatedItems);
      // Refresh dashboard data
      const dashboard = await dashboardService.getDashboardData();
      setDashboardData(dashboard);
      return result;
    } catch (error) {
      console.error('Error in bulk update:', error);
      throw error;
    }
  };

  // Refresh all data
  const refreshData = async () => {
    try {
      setLoading(true);
      
      // Fetch items
      const itemsData = await itemService.getAllItems();
      setItems(itemsData);
      
      // Fetch dashboard data
      const dashboard = await dashboardService.getDashboardData();
      setDashboardData(dashboard);
      
      setLoading(false);
    } catch (error) {
      console.error('Error refreshing data:', error);
      setError('Failed to refresh data. Please try again.');
      setLoading(false);
    }
  };

  const value = {
    items,
    dashboardData,
    metadata,
    loading,
    error,
    createItem,
    updateItem,
    deleteItem,
    archiveItem,
    bulkUpdateItems,
    refreshData
  };

  return (
    <InventoryContext.Provider value={value}>
      {children}
    </InventoryContext.Provider>
  );
};

export default InventoryContext;
