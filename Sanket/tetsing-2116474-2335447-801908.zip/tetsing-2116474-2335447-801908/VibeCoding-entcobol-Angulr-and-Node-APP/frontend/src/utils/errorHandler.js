/**
 * Global error handler for API requests
 * @param {Error} error - Error object from axios
 * @returns {Object} Formatted error object with message
 */
export const handleApiError = (error) => {
  console.error('API Error:', error);
  
  // Handle Axios errors
  if (error.response) {
    // The request was made and the server responded with a status code
    // that falls out of the range of 2xx
    const { status, data } = error.response;
    
    switch (status) {
      case 400:
        return {
          message: data.error || 'Invalid request. Please check your data and try again.',
          statusCode: 400
        };
      case 404:
        return {
          message: data.error || 'Resource not found.',
          statusCode: 404
        };
      case 500:
        return {
          message: data.error || 'Server error. Please try again later.',
          statusCode: 500
        };
      default:
        return {
          message: data.error || 'An unexpected error occurred. Please try again.',
          statusCode: status
        };
    }
  } else if (error.request) {
    // The request was made but no response was received
    return {
      message: 'No response from server. Please check your internet connection.',
      statusCode: 0
    };
  } else {
    // Something happened in setting up the request that triggered an Error
    return {
      message: error.message || 'An unexpected error occurred. Please try again.',
      statusCode: 0
    };
  }
};

/**
 * Toast configuration based on error type
 * @param {string} type - Error type (error, warning, info, success)
 * @returns {Object} Toast configuration
 */
export const toastConfig = (type = 'info') => {
  const config = {
    position: 'top-right',
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
  };
  
  return config;
};
