/**
 * Format a date to a readable format
 * @param {string} dateString - ISO format date string
 * @returns {string} Formatted date string
 */
export const formatDate = (dateString) => {
  if (!dateString) return '-';
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
};

/**
 * Format a number as currency
 * @param {number} number - The number to format
 * @returns {string} Formatted currency string
 */
export const formatCurrency = (number) => {
  if (number === undefined || number === null) return '-';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(number);
};

/**
 * Format an item status based on quantity
 * @param {Object} item - The inventory item
 * @returns {Object} Status object with label and color
 */
export const getItemStatus = (item) => {
  if (!item) return { label: 'Unknown', color: 'grey' };

  if (item.quantity <= 0) {
    return { label: 'Out of Stock', color: 'error' };
  } else if (item.quantity <= item.minStockThreshold) {
    return { label: 'Low Stock', color: 'warning' };
  } else {
    return { label: 'In Stock', color: 'success' };
  }
};

/**
 * Generate CSV format from array of objects
 * @param {Array} array - Array of objects to convert
 * @returns {string} CSV formatted string
 */
export const arrayToCSV = (array) => {
  if (!array || !array.length) return '';

  const header = Object.keys(array[0]).join(',') + '\n';
  const rows = array.map(obj => 
    Object.values(obj).map(value => 
      typeof value === 'string' && value.includes(',') 
        ? `"${value.replace(/"/g, '""')}"` 
        : value
    ).join(',')
  ).join('\n');

  return header + rows;
};

/**
 * Download data as a file
 * @param {string} content - Content to download
 * @param {string} fileName - Name of the file
 * @param {string} contentType - Content type (MIME type)
 */
export const downloadFile = (content, fileName, contentType) => {
  const a = document.createElement("a");
  const file = new Blob([content], { type: contentType });
  a.href = URL.createObjectURL(file);
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(a.href);
};

/**
 * Export data as CSV file
 * @param {Array} data - Array of objects to export
 * @param {string} filename - Name of the file
 */
export const exportToCSV = (data, filename = 'export.csv') => {
  const csv = arrayToCSV(data);
  downloadFile(csv, filename, 'text/csv');
};
