import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Button,
  Grid,
  Paper,
  Card,
  CardMedia,
  CardContent,
  Divider,
  Chip,
  TextField,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  Edit as EditIcon,
  ArrowBack as ArrowBackIcon,
} from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';
import { useInventory } from '../context/InventoryContext';

const ItemDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { items, updateItem, loading: inventoryLoading } = useInventory();
  
  const [item, setItem] = useState(null);
  const [qtyInputValue, setQtyInputValue] = useState('');
  const [adjustingQty, setAdjustingQty] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (items.length > 0) {
      const foundItem = items.find(item => item.id === id);
      if (foundItem) {
        setItem(foundItem);
        setQtyInputValue(foundItem.quantity.toString());
      } else {
        setError('Item not found');
      }
    }
  }, [id, items]);

  const handleUpdateQuantity = async (e) => {
    e.preventDefault();
    
    if (!qtyInputValue || parseInt(qtyInputValue) < 0) {
      return;
    }
    
    try {
      setAdjustingQty(true);
      
      const updatedItem = await updateItem(id, {
        ...item,
        quantity: parseInt(qtyInputValue),
      });
      
      setItem(updatedItem);
      setAdjustingQty(false);
    } catch (err) {
      console.error('Error updating quantity:', err);
      setError(err.message || 'Failed to update quantity');
      setAdjustingQty(false);
    }
  };

  if (inventoryLoading || !item) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Alert severity="error">{error}</Alert>
        <Button
          variant="contained"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/inventory')}
          sx={{ mt: 2 }}
        >
          Back to Inventory
        </Button>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between' }}>
        <Button
          variant="outlined"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/inventory')}
        >
          Back to Inventory
        </Button>
        
        <Button
          variant="contained"
          startIcon={<EditIcon />}
          onClick={() => navigate(`/inventory/edit/${id}`)}
        >
          Edit Item
        </Button>
      </Box>

      <Grid container spacing={4}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardMedia
              component="img"
              height="300"
              image={item.imageUrl || "https://via.placeholder.com/300"}
              alt={item.name}
              sx={{ objectFit: 'contain', p: 2 }}
            />
            <CardContent>
              <Typography variant="h5" component="div" gutterBottom>
                {item.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                SKU: {item.sku}
              </Typography>
              <Box sx={{ mt: 2, display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                <Chip label={item.category} color="primary" />
                {item.archived && <Chip label="Archived" />}
                {item.quantity === 0 ? (
                  <Chip label="Out of Stock" color="error" />
                ) : item.quantity <= item.minStockThreshold ? (
                  <Chip label="Low Stock" color="warning" />
                ) : (
                  <Chip label="In Stock" color="success" />
                )}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Item Details
            </Typography>
            <Divider sx={{ mb: 2 }} />

            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Description</Typography>
                <Typography variant="body1" paragraph>
                  {item.description}
                </Typography>
              </Grid>

              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Supplier</Typography>
                <Typography variant="body1" paragraph>
                  {item.supplier}
                </Typography>
              </Grid>

              <Grid item xs={6} sm={3}>
                <Typography variant="subtitle2">Price</Typography>
                <Typography variant="body1" paragraph>
                  ${Number(item.price).toFixed(2)}
                </Typography>
              </Grid>

              <Grid item xs={6} sm={3}>
                <Typography variant="subtitle2">Min Threshold</Typography>
                <Typography variant="body1" paragraph>
                  {item.minStockThreshold}
                </Typography>
              </Grid>

              <Grid item xs={12}>
                <Box sx={{ mt: 2 }}>
                  <Typography variant="h6" gutterBottom>
                    Stock Management
                  </Typography>
                  <Divider sx={{ mb: 2 }} />

                  <Grid container spacing={2} alignItems="center">
                    <Grid item xs={12} sm={6}>
                      <Typography variant="body1">
                        Current Stock: <strong>{item.quantity}</strong>
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Box component="form" onSubmit={handleUpdateQuantity} sx={{ display: 'flex', gap: 2 }}>
                        <TextField
                          label="Adjust Quantity"
                          type="number"
                          value={qtyInputValue}
                          onChange={(e) => setQtyInputValue(e.target.value)}
                          sx={{ flexGrow: 1 }}
                          InputProps={{ inputProps: { min: 0 } }}
                          size="small"
                        />
                        <Button
                          type="submit"
                          variant="contained"
                          disabled={adjustingQty}
                          size="small"
                        >
                          {adjustingQty ? <CircularProgress size={24} /> : 'Update'}
                        </Button>
                      </Box>
                    </Grid>
                  </Grid>
                </Box>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ItemDetail;
