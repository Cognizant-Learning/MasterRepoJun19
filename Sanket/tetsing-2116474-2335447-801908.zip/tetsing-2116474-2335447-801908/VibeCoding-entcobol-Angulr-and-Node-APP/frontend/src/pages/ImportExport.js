import React, { useState } from 'react';
import {
  Container,
  Typography,
  Box,
  Grid,
  Paper,
  Button,
  TextField,
  Alert,
  Snackbar,
  Tabs,
  Tab,
  CircularProgress,
} from '@mui/material';
import {
  Upload as UploadIcon,
  Download as DownloadIcon,
} from '@mui/icons-material';
import { useInventory } from '../context/InventoryContext';
import { importExportService } from '../services/api';

const ImportExport = () => {
  const { items, refreshData } = useInventory();
  const [activeTab, setActiveTab] = useState(0);
  const [importData, setImportData] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleImportDataChange = (e) => {
    setImportData(e.target.value);
  };

  const handleImport = async () => {
    if (!importData.trim()) {
      setError('Please enter valid JSON data');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Parse the JSON data
      const parsedData = JSON.parse(importData);
      
      // Validate that it's an array
      if (!Array.isArray(parsedData)) {
        throw new Error('Import data must be an array of items');
      }

      // Send to API
      await importExportService.importItems(parsedData);
      
      // Refresh data
      await refreshData();
      
      // Show success message
      setSnackbar({
        open: true,
        message: `Successfully imported ${parsedData.length} items`,
        severity: 'success',
      });
      
      // Clear the import data field
      setImportData('');
    } catch (error) {
      console.error('Import error:', error);
      setError(`Import failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    try {
      // Prepare data for export - exclude archived items if needed
      const exportData = items.filter(item => !item.archived);
      
      // Convert to JSON string
      const jsonData = JSON.stringify(exportData, null, 2);
      
      // Create blob and download link
      const blob = new Blob([jsonData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      
      link.href = url;
      link.download = `inventory_export_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      setSnackbar({
        open: true,
        message: 'Export successful',
        severity: 'success',
      });
    } catch (error) {
      console.error('Export error:', error);
      setError(`Export failed: ${error.message}`);
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Import / Export
      </Typography>

      <Paper sx={{ mb: 4 }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="fullWidth"
        >
          <Tab label="Import" />
          <Tab label="Export" />
        </Tabs>

        <Box p={3}>
          {activeTab === 0 ? (
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>
                  Import Inventory Items
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  Paste JSON data below. It should be an array of objects with name, description, category, etc.
                </Typography>
              </Grid>

              {error && (
                <Grid item xs={12}>
                  <Alert severity="error">{error}</Alert>
                </Grid>
              )}

              <Grid item xs={12}>
                <TextField
                  label="JSON Data"
                  multiline
                  rows={10}
                  value={importData}
                  onChange={handleImportDataChange}
                  fullWidth
                  variant="outlined"
                  placeholder='[{"name": "Example Item", "description": "Example description", "category": "Electronics", "sku": "EX-123", "price": 19.99, "quantity": 10, "supplier": "Example Supplier", "minStockThreshold": 3}]'
                />
              </Grid>

              <Grid item xs={12}>
                <Button
                  variant="contained"
                  color="primary"
                  startIcon={loading ? <CircularProgress size={20} color="inherit" /> : <UploadIcon />}
                  onClick={handleImport}
                  disabled={loading}
                  fullWidth
                >
                  Import Items
                </Button>
              </Grid>
            </Grid>
          ) : (
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom>
                  Export Inventory Items
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  Export your current inventory items as a JSON file.
                </Typography>
              </Grid>

              <Grid item xs={12}>
                <Paper variant="outlined" sx={{ p: 3, mb: 2, bgcolor: 'background.default' }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box>
                      <Typography variant="body1" gutterBottom>
                        <strong>Current Inventory</strong>
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {items.length} items available for export
                      </Typography>
                    </Box>
                    <Button
                      variant="contained"
                      color="primary"
                      startIcon={<DownloadIcon />}
                      onClick={handleExport}
                      disabled={items.length === 0}
                    >
                      Export as JSON
                    </Button>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          )}
        </Box>
      </Paper>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default ImportExport;
