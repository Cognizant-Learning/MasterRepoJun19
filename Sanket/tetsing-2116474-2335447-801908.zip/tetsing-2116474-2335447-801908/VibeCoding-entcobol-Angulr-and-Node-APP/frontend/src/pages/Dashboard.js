import React from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Paper, 
  Box, 
  List, 
  ListItem, 
  ListItemText, 
  Divider,
  CircularProgress,
  Alert,
} from '@mui/material';
import { 
  Inventory as InventoryIcon, 
  Warning as WarningIcon, 
  RemoveShoppingCart as OutOfStockIcon,
} from '@mui/icons-material';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { useInventory } from '../context/InventoryContext';
import StatCard from '../components/StatCard';

// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

const Dashboard = () => {
  const { 
    dashboardData, 
    items, 
    loading, 
    error 
  } = useInventory();

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ mt: 2 }}>
        {error}
      </Alert>
    );
  }

  const { summary, recentActivity } = dashboardData;

  // Prepare chart data
  const chartData = {
    labels: ['In Stock', 'Low Stock', 'Out of Stock'],
    datasets: [
      {
        data: [
          summary.totalItems - summary.lowStockItems - summary.outOfStockItems,
          summary.lowStockItems,
          summary.outOfStockItems,
        ],
        backgroundColor: [
          'rgba(54, 162, 235, 0.6)',
          'rgba(255, 206, 86, 0.6)',
          'rgba(255, 99, 132, 0.6)',
        ],
        borderColor: [
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(255, 99, 132, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>

      <Grid container spacing={3}>
        {/* Summary Statistics */}
        <Grid item xs={12} md={4}>
          <StatCard
            title="Total Items"
            value={summary.totalItems}
            icon={<InventoryIcon fontSize="large" />}
            bgcolor="#3f51b5" // blue
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <StatCard
            title="Low Stock Items"
            value={summary.lowStockItems}
            icon={<WarningIcon fontSize="large" />}
            bgcolor="#ff9800" // amber
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <StatCard
            title="Out of Stock Items"
            value={summary.outOfStockItems}
            icon={<OutOfStockIcon fontSize="large" />}
            bgcolor="#f44336" // red
          />
        </Grid>

        {/* Inventory Level Chart */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Inventory Levels
            </Typography>
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 300 }}>
              {items.length > 0 ? (
                <Doughnut data={chartData} options={{ maintainAspectRatio: false }} />
              ) : (
                <Typography variant="body1" color="text.secondary">
                  No inventory data available
                </Typography>
              )}
            </Box>
          </Paper>
        </Grid>

        {/* Recent Activity Log */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Recent Activity
            </Typography>
            {recentActivity && recentActivity.length > 0 ? (
              <List>
                {recentActivity.map((activity, index) => (
                  <React.Fragment key={activity.id || index}>
                    <ListItem>
                      <ListItemText
                        primary={activity.details}
                        secondary={new Date(activity.timestamp).toLocaleString()}
                      />
                    </ListItem>
                    {index < recentActivity.length - 1 && <Divider />}
                  </React.Fragment>
                ))}
              </List>
            ) : (
              <Typography variant="body1" color="text.secondary">
                No recent activity
              </Typography>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Dashboard;
