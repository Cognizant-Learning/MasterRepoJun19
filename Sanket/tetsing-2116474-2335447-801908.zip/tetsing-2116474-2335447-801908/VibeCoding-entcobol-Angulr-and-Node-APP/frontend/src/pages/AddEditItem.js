import React, { useState, useEffect } from 'react';
import { Container, Typography, Box, Button, Paper, CircularProgress, Alert } from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import { useInventory } from '../context/InventoryContext';
import ItemForm from '../components/ItemForm';

const AddEditItem = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { 
    createItem, 
    updateItem, 
    metadata, 
    items, 
    loading: inventoryLoading 
  } = useInventory();
  
  const [currentItem, setCurrentItem] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const isEditMode = Boolean(id);

  // Find the item if in edit mode
  useEffect(() => {
    if (isEditMode && items.length > 0) {
      const item = items.find(item => item.id === id);
      if (item) {
        setCurrentItem(item);
      } else {
        setError('Item not found');
      }
    }
  }, [isEditMode, id, items]);

  const handleSubmit = async (values) => {
    setLoading(true);
    setError(null);
    
    try {
      if (isEditMode) {
        await updateItem(id, values);
        navigate('/inventory');
      } else {
        await createItem(values);
        navigate('/inventory');
      }
    } catch (err) {
      console.error('Error saving item:', err);
      setError(err.message || 'An error occurred while saving the item');
    } finally {
      setLoading(false);
    }
  };

  const initialValues = currentItem || {
    name: '',
    description: '',
    category: '',
    sku: '',
    price: '',
    quantity: '',
    supplier: '',
    imageUrl: 'https://via.placeholder.com/150',
    minStockThreshold: '5',
  };

  if (inventoryLoading && isEditMode) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error && isEditMode) {
    return (
      <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
        <Button variant="contained" onClick={() => navigate('/inventory')}>
          Return to Inventory
        </Button>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ mb: 4 }}>
        <Button variant="outlined" onClick={() => navigate('/inventory')} sx={{ mb: 2 }}>
          Back to Inventory
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <ItemForm
        initialValues={initialValues}
        onSubmit={handleSubmit}
        categories={metadata.categories || []}
        suppliers={metadata.suppliers || []}
        isLoading={loading}
        isEditMode={isEditMode}
      />
    </Container>
  );
};

export default AddEditItem;
