import React, { useState } from 'react';
import {
  Container,
  Typography,
  Box,
  Button,
  IconButton,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  Grid,
  Alert,
  Snackbar,
  Chip,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Archive as ArchiveIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useInventory } from '../context/InventoryContext';
import InventoryTable from '../components/InventoryTable';
import ConfirmDialog from '../components/ConfirmDialog';

const Inventory = () => {
  const navigate = useNavigate();
  const { items, loading, error, deleteItem, archiveItem, bulkUpdateItems, refreshData } = useInventory();
  
  const [selectedItems, setSelectedItems] = useState([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [archiveDialogOpen, setArchiveDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [itemToArchive, setItemToArchive] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  // Format columns for the data grid
  const columns = [
    { field: 'id', headerName: 'ID', width: 70, hide: true },
    { 
      field: 'name', 
      headerName: 'Name', 
      width: 200,
      renderCell: (params) => (
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          {params.row.imageUrl && (
            <img
              src={params.row.imageUrl}
              alt={params.row.name}
              style={{ width: 32, height: 32, marginRight: 8, borderRadius: '50%' }}
            />
          )}
          {params.row.name}
        </Box>
      ),
    },
    { field: 'sku', headerName: 'SKU', width: 120 },
    { field: 'category', headerName: 'Category', width: 150 },
    { 
      field: 'price', 
      headerName: 'Price', 
      width: 120,
      valueFormatter: (params) => `$${params.value.toFixed(2)}`,
    },
    { 
      field: 'quantity', 
      headerName: 'Quantity', 
      width: 120,
      renderCell: (params) => {
        const { quantity, minStockThreshold } = params.row;
        
        if (quantity === 0) {
          return <Chip label="Out of Stock" color="error" size="small" />;
        } else if (quantity <= minStockThreshold) {
          return <Chip label={`Low: ${quantity}`} color="warning" size="small" />;
        }
        
        return quantity;
      },
    },
    { field: 'supplier', headerName: 'Supplier', width: 180 },
    {
      field: 'archived',
      headerName: 'Status',
      width: 120,
      renderCell: (params) => (
        params.value ? 
        <Chip label="Archived" color="default" size="small" /> : 
        <Chip label="Active" color="success" size="small" />
      ),
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 150,
      sortable: false,
      renderCell: (params) => (
        <Box>
          <Tooltip title="Edit">
            <IconButton
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/inventory/edit/${params.row.id}`);
              }}
              size="small"
            >
              <EditIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          
          {!params.row.archived ? (
            <Tooltip title="Archive">
              <IconButton
                onClick={(e) => {
                  e.stopPropagation();
                  handleArchiveClick(params.row);
                }}
                size="small"
              >
                <ArchiveIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          ) : null}
          
          <Tooltip title="Delete">
            <IconButton
              onClick={(e) => {
                e.stopPropagation();
                handleDeleteClick(params.row);
              }}
              size="small"
              color="error"
            >
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ];

  // Handle item actions
  const handleDeleteClick = (item) => {
    setItemToDelete(item);
    setDeleteDialogOpen(true);
  };

  const handleArchiveClick = (item) => {
    setItemToArchive(item);
    setArchiveDialogOpen(true);
  };

  const handleItemDelete = async () => {
    if (!itemToDelete) return;
    
    setActionLoading(true);
    try {
      await deleteItem(itemToDelete.id);
      setSnackbar({
        open: true,
        message: `"${itemToDelete.name}" has been deleted.`,
        severity: 'success',
      });
    } catch (error) {
      console.error('Error deleting item:', error);
      setSnackbar({
        open: true,
        message: `Failed to delete item: ${error.message}`,
        severity: 'error',
      });
    } finally {
      setActionLoading(false);
      setDeleteDialogOpen(false);
      setItemToDelete(null);
    }
  };

  const handleItemArchive = async () => {
    if (!itemToArchive) return;
    
    setActionLoading(true);
    try {
      await archiveItem(itemToArchive.id);
      setSnackbar({
        open: true,
        message: `"${itemToArchive.name}" has been archived.`,
        severity: 'success',
      });
    } catch (error) {
      console.error('Error archiving item:', error);
      setSnackbar({
        open: true,
        message: `Failed to archive item: ${error.message}`,
        severity: 'error',
      });
    } finally {
      setActionLoading(false);
      setArchiveDialogOpen(false);
      setItemToArchive(null);
    }
  };

  const handleRowClick = (params) => {
    navigate(`/inventory/view/${params.row.id}`);
  };

  const handleSelectionModelChange = (newSelectionModel) => {
    setSelectedItems(newSelectionModel);
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" gutterBottom>
          Inventory Items
        </Typography>
        
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => navigate('/inventory/add')}
        >
          Add New Item
        </Button>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <InventoryTable
            rows={items}
            columns={columns}
            loading={loading}
            onRowClick={handleRowClick}
            checkboxSelection
            selectionModel={selectedItems}
            onSelectionModelChange={handleSelectionModelChange}
          />
        </Grid>
      </Grid>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        onConfirm={handleItemDelete}
        title="Delete Item"
        content={`Are you sure you want to delete "${itemToDelete?.name}"? This action cannot be undone.`}
        confirmText="Delete"
        confirmButtonColor="error"
        isLoading={actionLoading}
      />

      {/* Archive Confirmation Dialog */}
      <ConfirmDialog
        open={archiveDialogOpen}
        onClose={() => setArchiveDialogOpen(false)}
        onConfirm={handleItemArchive}
        title="Archive Item"
        content={`Are you sure you want to archive "${itemToArchive?.name}"?`}
        confirmText="Archive"
        isLoading={actionLoading}
      />

      {/* Notification Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default Inventory;
