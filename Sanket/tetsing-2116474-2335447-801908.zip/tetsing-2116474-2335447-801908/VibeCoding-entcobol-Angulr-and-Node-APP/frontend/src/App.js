import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline, Box } from '@mui/material';
import { InventoryProvider } from './context/InventoryContext';

// Components
import Navbar from './components/Navbar';

// Pages
import Dashboard from './pages/Dashboard';
import Inventory from './pages/Inventory';
import AddEditItem from './pages/AddEditItem';
import ItemDetail from './pages/ItemDetail';
import ImportExport from './pages/ImportExport';
import './App.css';

// Create a theme
const theme = createTheme({
  palette: {
    primary: {
      main: '#3f51b5',
    },
    secondary: {
      main: '#f50057',
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <InventoryProvider>
        <Router>
          <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
            <Navbar />
            <Box component="main" sx={{ flexGrow: 1, py: 3 }}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/inventory" element={<Inventory />} />
                <Route path="/inventory/add" element={<AddEditItem />} />
                <Route path="/inventory/edit/:id" element={<AddEditItem />} />
                <Route path="/inventory/view/:id" element={<ItemDetail />} />
                <Route path="/import-export" element={<ImportExport />} />
              </Routes>
            </Box>
          </Box>
        </Router>
      </InventoryProvider>
    </ThemeProvider>
  );
}

export default App;
