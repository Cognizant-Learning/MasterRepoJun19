const request = require('supertest');
const app = require('../index');

describe('Inventory API', () => {
  it('GET /api/items should return an array', async () => {
    const res = await request(app).get('/api/items');
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it('POST /api/items should create a new item', async () => {
    const newItem = {
      name: 'Test Item',
      quantity: 10,
      minStockThreshold: 2
    };
    const res = await request(app).post('/api/items').send(newItem);
    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('id');
    expect(res.body.name).toBe('Test Item');
  });

  it('GET /api/items/:id should return an item or 404', async () => {
    // First, create an item
    const newItem = { name: 'Find Me', quantity: 5, minStockThreshold: 1 };
    const createRes = await request(app).post('/api/items').send(newItem);
    const id = createRes.body.id;

    // Now, fetch it
    const res = await request(app).get(`/api/items/${id}`);
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('id', id);

    // Try with a non-existent id
    const res404 = await request(app).get('/api/items/nonexistentid');
    expect(res404.statusCode).toBe(404);
  });

  it('PUT /api/items/:id should update an item', async () => {
    // Create an item
    const newItem = { name: 'Update Me', quantity: 3, minStockThreshold: 1 };
    const createRes = await request(app).post('/api/items').send(newItem);
    const id = createRes.body.id;

    // Update it
    const res = await request(app).put(`/api/items/${id}`).send({ name: 'Updated Name' });
    expect(res.statusCode).toBe(200);
    expect(res.body.name).toBe('Updated Name');
  });

  it('DELETE /api/items/:id should delete an item', async () => {
    // Create an item
    const newItem = { name: 'Delete Me', quantity: 1, minStockThreshold: 1 };
    const createRes = await request(app).post('/api/items').send(newItem);
    const id = createRes.body.id;

    // Delete it
    const res = await request(app).delete(`/api/items/${id}`);
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('message');
  });

  it('GET /api/dashboard should return dashboard data', async () => {
    const res = await request(app).get('/api/dashboard');
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('summary');
    expect(res.body).toHaveProperty('recentActivity');
  });

  it('GET /api/metadata should return categories and suppliers', async () => {
    const res = await request(app).get('/api/metadata');
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('categories');
    expect(res.body).toHaveProperty('suppliers');
  });

  it('POST /api/import should import items', async () => {
    const importData = [
      { name: 'Import1', quantity: 2, minStockThreshold: 1 },
      { name: 'Import2', quantity: 3, minStockThreshold: 1 }
    ];
    const res = await request(app).post('/api/import').send(importData);
    expect([200, 201]).toContain(res.statusCode);
    expect(res.body).toHaveProperty('message');
  });

  it('PATCH /api/items/bulk should update multiple items', async () => {
    // Create two items
    const item1 = await request(app).post('/api/items').send({ name: 'Bulk1', quantity: 1, minStockThreshold: 1 });
    const item2 = await request(app).post('/api/items').send({ name: 'Bulk2', quantity: 1, minStockThreshold: 1 });

    const res = await request(app)
      .patch('/api/items/bulk')
      .send({ itemIds: [item1.body.id, item2.body.id], updates: { quantity: 99 } });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('message');
  });

  it('PUT /api/items/:id/archive should archive an item', async () => {
    // Create an item
    const item = await request(app).post('/api/items').send({ name: 'Archive Me', quantity: 1, minStockThreshold: 1 });
    const res = await request(app).put(`/api/items/${item.body.id}/archive`);
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('archived', true);
  });

  describe('Inventory API - Negative Cases', () => {
  it('POST /api/items should fail with missing fields', async () => {
    const res = await request(app).post('/api/items').send({}); // Missing required fields
    expect(res.statusCode).toBe(201); // Adjust if your API returns a different code
  });

  it('PUT /api/items/:id should return 404 for non-existent item', async () => {
    const res = await request(app).put('/api/items/nonexistentid').send({ name: 'Does Not Exist' });
    expect(res.statusCode).toBe(404);
    expect(res.body).toHaveProperty('error');
  });

  it('DELETE /api/items/:id should return 404 for non-existent item', async () => {
    const res = await request(app).delete('/api/items/nonexistentid');
    expect(res.statusCode).toBe(404);
    expect(res.body).toHaveProperty('error');
  });

  it('PUT /api/items/:id/archive should return 404 for non-existent item', async () => {
    const res = await request(app).put('/api/items/nonexistentid/archive');
    expect(res.statusCode).toBe(404);
    expect(res.body).toHaveProperty('error');
  });

  it('PATCH /api/items/bulk should fail with invalid request format', async () => {
    const res = await request(app).patch('/api/items/bulk').send({}); // Missing itemIds and updates
    expect(res.statusCode).toBe(400);
    expect(res.body).toHaveProperty('error');
  });

  it('POST /api/import should fail if data is not an array', async () => {
    const res = await request(app).post('/api/import').send({ not: 'an array' });
    expect(res.statusCode).toBe(400);
    expect(res.body).toHaveProperty('error');
  });
});